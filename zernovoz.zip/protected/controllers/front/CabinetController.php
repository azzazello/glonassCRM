<?php

class CabinetController extends ControlerCPanel
{
	public function actionIndex()
	{
		$this->render('index');
	}
}