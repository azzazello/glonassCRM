<?php


$LIMIT_DAY_FUTURE = 3;