<?php

Yii::import('application.models._base.BaseReplyShipping');

class ReplyShipping extends BaseReplyShipping
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}